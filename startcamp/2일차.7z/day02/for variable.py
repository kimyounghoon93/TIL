items = ['1','2','3']

for i in items:
    print(i)

print(i)